/*package com.Final.Project.Exception;

public class PortalException extends Exception	{
	
	public PortalException(String message) 
	{
        super(message);
    }

    public PortalException(String message, Throwable cause) 
    {
        super(message, cause);
    }
}
*/