This is a web application, developed based on MVC architecture using spring, hibernate, maven & mySql. 
It is similar to any other job portal where recruiters post jobs & interested candidates apply. 

Both user types sign up & manage their profile details. Recruiter can see list of candidates
applied to his posted job while job-seeker can see the list of jobs he applied to.
